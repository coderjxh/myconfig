VIM-CMake-Project v2.0.1
===============

About
=====
CMake project management plugin for VIM editor.

[![VCP](http://i.imgur.com/wGeVbl.png)](http://i.imgur.com/wGeVbl.png)

Installing
==========
  
    $ make install

Specify the DESTDIR variable to install it to the other directory.

License
=======
This product is released under the [BSD License](http://opensource.org/licenses/bsd-3-clause).
